function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$Base64Data,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)
    process
    {
	    return @{
		    Filename = $Filename
            NetscalerIP = $NetscalerIP
		    Base64Data = $Base64Data
            Reboot = $Reboot
            UseHttps = $UseHttps
            Ensure = $Ensure
	    }
    }
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$Base64Data,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)
	
    begin
    {
	    if(-not $Base64Data)
	    {
		    throw "Invalid argument specified for Base64Data"
	    }
	}

    process
    {
	    if($UseHttps)
	    {
		    Set-Protocol "HTTPS"
	    }
	    else
	    {
		    Set-Protocol "HTTP"
	    }
	
	    $username = $NetscalerCredential.UserName
	    $password  = $NetscalerCredential.GetNetworkCredential().password
	
        $path = (Split-Path -Path $Filename).Replace("\", "/")
	    $name = Split-Path -Path $Filename -Leaf

        if($Ensure -eq "Present")
        {
            # Send file over Nitro, then rename

            $session = Connect-NSVPX -NSIP $NetscalerIP -NSUserName $username -NSPassword $password

            Send-NetscalerSystemFile -NSIP $NetscalerIP -Filename "temp.txt" -Location $path `
                                     -Base64Data $Base64Data -WebSession $session

            Invoke-NetscalerSSH -Hostname $NetscalerIP -Credentials $NetscalerCredential `
                                -Commands "mv $path/temp.txt $path/$name"
        }
        else 
        {
            Invoke-NetscalerSSH -Hostname $NetscalerIP -Credentials $NetscalerCredential `
                                -Commands "rm $Filename"
        }

        if($Reboot)
        {
            # If restarting for changes to take effect, expect underlying connection to close.

            try {
                Restart-NetScalerVpx -NSIP $NetscalerIP -SaveNSConfig -WebSession $session | Out-Null
            } catch { }
        }
    }
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$Base64Data,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)
	
	begin
    {
	    if(-not $Base64Data)
	    {
		    throw "Invalid argument specified for Base64Data"
	    }
	}

    process
    {
        # Check target file to see if it matches the intended

	    $username = $NetscalerCredential.UserName
	    $password = $NetscalerCredential.GetNetworkCredential().password
	
	    $path = (Split-Path -Path $Filename).Replace("\", "/")
	    $name = Split-Path -Path $Filename -Leaf
	
        $output = Invoke-NetscalerSSH -Hostname $NetscalerIP -Credentials $NetscalerCredential `
                                      -Commands "ls $path"
	
        if($Ensure -eq "Present")
        {
    	    return (-not (($output | ?{$_ -match $name }) -eq $null))
        }
        else 
        {
    	    return ((($output | ?{$_ -match $name }) -eq $null))
        }
    }
}

. "$PSScriptRoot\..\NetScalerConfiguration.ps1"

Export-ModuleMember -Function *-TargetResource

