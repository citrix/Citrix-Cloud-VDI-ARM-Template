function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$DomainCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CertificateFile,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StorefrontServer,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VirtualServerName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$VirtualServerPort,
		
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$ForwardServerPort
	)

    process{
	    return @{
            NetscalerIP = $NetscalerIP
            DomainName = $DomainName
            CertificateFile = $CertificateFile
            DomainController = $DomainController
            StorefrontServer = $StorefrontServer
            DeliveryController = $DeliveryController
            VirtualServerName = $VirtualServerName
            VirtualServerPort = $VirtualServerPort
            ForwardServerPort = $ForwardServerPort
	    }
    }
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$DomainCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CertificateFile,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StorefrontServer,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VirtualServerName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$VirtualServerPort,
		
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$ForwardServerPort
	)
    
    begin
    {
	    $trustCertsCode = @"
	    using System.Net;
	    using System.Security.Cryptography.X509Certificates;
	    public class TrustAllCertsPolicy : ICertificatePolicy {
		    public bool CheckValidationResult(
			    ServicePoint srvPoint, X509Certificate certificate,
			    WebRequest request, int certificateProblem) {
			    return true;
		    }
	    }
"@
    }

    process
    {
        # This is all very procedural, and ideally we would like to modularize these steps into more
        # atomic resources. This also awkwardly modeled as DSC because the desired state is for another
        # machine which doesn't have a clean configuration model.

	    $VirtualServerIP = $NetscalerIP
	    $LDAPLoginName = "sAMAccountName"
	
	    $username = $NetscalerCredential.UserName
	    $password = $NetscalerCredential.GetNetworkCredential().Password

	    $domainUsername = $DomainCredential.UserName
	    $domainPassword = $DomainCredential.GetNetworkCredential().Password

        $certPassword = $CertificatePassword.GetNetworkCredential().Password

	    $domainBase = [string]::Join(",", ($DomainName.Split(".") | %{"dc=$_"}))
	
	    $certName = "certificate"
	    
        # Setup HTTPS for the following configuration

	    Set-Protocol "HTTP"

        

	    $session = Connect-NSVPX -NSIP $NetScalerIP -NSUserName $username -NSPassword $password

		
        

	    Enable-NSVPXFeature -NSIP $NetScalerIP -Features "sslvpn ssl responder loadbalancing" -WebSession $session

        

	    ##Invoke-NetscalerSSHRaw -Hostname $NetscalerIP -Username $username -Password $password `
                             ##  -Commands "add ssl certKey ns-server-certificate -cert ns-server.cert -key ns-server.key"

	    Set-Protocol "HTTPS"
	
	    Add-Type $trustCertsCode
	
	    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
	
        # Configure NetScaler VServer for StoreFront with the given certificate

        if($CertificateFile -match "pfx")
        {
            # Support pfx files by converting to the correct format
            $OutFile = $CertificateFile -replace 'pfx', 'pem'

            Invoke-NetscalerSSHRaw -Hostname $NetscalerIP -Credentials $NetscalerCredential `
                               -Commands "convert ssl pkcs12 $OutFile -import -pkcs12File $CertificateFile -des -password $certPassword -PEMPassPhrase $certPassword"

            $CertificateFile = $OutFile
        }

        
        

	    Add-DNSServer -NSIP $NetScalerIP -DNSServerIP $DomainController -WebSession $session

        

		Add-CertKeyPair -NSIP $NetScalerIP -CertKeyName $certName -CertPath "certificate.pem" -KeyPath "certificate.pem" `
                            -CertKeyFormat PEM -Password $certPassword -WebSession $session 
	
        
	    
       

	    Add-VServer -NSIP $NetScalerIP -VServerName $($VirtualServerName) -VServerIP $($VirtualServerIP) `
                    -VServerPort $VirtualServerPort -WebSession $session
       

	    New-VServeSSLCertKeyBinding -NSIP $NetScalerIP -CertKeyName $certName -VServerName $($VirtualServerName) `
                                    -WebSession $session
	    
		Set-NetScalerSFStore -NSIP $($NetScalerIP) -VirtualServerName $($VirtualServerName) -VirtualServerIP $($VirtualServerIP) `
                             -StoreFrontServer $StorefrontServer -STAServerURL "http://$DeliveryController" `
                             -SingleSignOnDomain $($DomainName) -WebSession $session|out-null
        
	
       # Other customizations

	   # Set-UItheme -NSIP $($NetScalerIP) -Theme GreenBubble -WebSession $session
       
        
        Invoke-NetscalerSSHRaw -Hostname $NetscalerIP  -Credentials $NetscalerCredential `
                               -Commands """bind vpn vserver $VirtualServerName -portaltheme X1"""

	           
         Enable-NSVPXMode -NSIP $NetScalerIP -Modes "mbf" -WebSession $session

	    # Set up HTTP forwarding
               

	    Add-ResponderAction -NSIP $NetScalerIP -Name http_to_https -Type redirect `
                           -Target '"https:" + "//" + HTTP.REQ.HOSTNAME.HTTP_URL_SAFE + HTTP.REQ.URL.PATH_AND_QUERY.HTTP_URL_SAFE' `
                           -WebSession $session
               

	    Add-ResponderPolicy -NSIP $NetScalerIP -Name http_to_https_pol -ActionName http_to_https -UndefinedAction RESET `
                            -Expression HTTP.REQ.IS_VALID -WebSession $session

	    Add-Monitor -NSIP $NetScalerIP -MonitorName localhost_ping -Type PING -destIP "127.0.0.1" -WebSession $session -LRTM Enabled
	    Add-Server -NSIP $NetScalerIP -Name Dummy_server -IPaddress "1.2.3.4" -WebSession $session
	    Add-Service -NSIP $NetScalerIP -name Always_UP_Service -ServerName "Dummy_server" -ServiceType HTTP -Port $ForwardServerPort `
                    -WebSession $session
	    Add-MonitorServiceBinding -NSIP $NetScalerIP -ServiceName Always_UP_Service -MonitorName localhost_ping -WebSession $session
	    Add-LBVserver -NSIP $NetScalerIP -Name http_server -ServiceType HTTP -IPAddress $NetScalerIP -port $ForwardServerPort `
                      -persistenceType COOKIEINSERT -timeout 0 -cltTimeout 180 -WebSession $session
	    Add-LBVServerServiceBinding -NSIP $NetScalerIP -LBVServerName http_server -ServiceName Always_UP_service -WebSession $session
	    Add-LBVServerPolicyBinding -NSIP $NetScalerIP -LBVServerName http_server -PolicyName http_to_https_pol -Priority 1 `
                                   -GotoPriorityExpression "END" -WebSession $session
	
	    # Restart NetScaler to make these changes active. Expect underlying connection to close.

	    try {
		    Restart-NetScalerVpx -NSIP $NetscalerIP -SaveNSConfig -WebSession $session -ErrorAction SilentlyContinue | Out-Null
	    } catch { }
    }
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$DomainCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CertificateFile,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StorefrontServer,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VirtualServerName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$VirtualServerPort,
		
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$ForwardServerPort
	)

	process
    {
	    $VirtualServerIP = $NetscalerIP

	    $username = $NetscalerCredential.UserName
	    $password = $NetscalerCredential.GetNetworkCredential().Password

	    Set-Protocol "HTTP"

	    $session = Connect-NSVPX -NSIP $NetScalerIP -NSUserName $username -NSPassword $password
	    $json = Get-DNSServer -NSIP $NetscalerIP -WebSession $session
	
	    return ($json -and (Get-Member -inputobject $json -name "dnsnameserver" -Membertype Properties) `
                      -and (-not (($json.dnsnameserver | ?{$_.ip -match $DomainController }) -eq $null)) )
    }
}

. "$PSScriptRoot\..\NetScalerConfiguration.ps1"

Export-ModuleMember -Function *-TargetResource

