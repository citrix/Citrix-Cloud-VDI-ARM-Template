#
# CitrixCloudConnector.ps1
#
configuration CitrixCloudConnector
{
    param
    (
		[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
		
		[Parameter(Mandatory)]
        [String]$DomainName,
 
		[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$DomainCreds,
		
        [Parameter(Mandatory)]
        [String]$DomainControllerIp,
					
        [Parameter(Mandatory)]
        [String]$CustomerId,
		
        [Parameter(Mandatory)]
        [String]$ClientId,
		
        [Parameter(Mandatory)]
        [String]$ClientSecret,
		
        [Parameter(Mandatory)]
        [String]$customerResourceLocationsId,
						
		[String]$CustomCloudConnectorScriptUri,
		
		[string]$CustomCloudConnectorScriptArgs
)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
	Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xCertificate, xWebAdministration, CitrixNetscaler,ACMEPowerShell, ACMECertificate, xSmbShare, xNetworking, CitrixMarketplace
	Import-DSCResource -Module xSystemSecurity -Name xIEEsc 
    Import-DSCResource -ModuleName CloudConnector -Name CloudConnector  -ModuleVersion 1.0
	
	[System.Management.Automation.PSCredential]$DomainCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($DomainCreds.UserName)", $DomainCreds.Password)
	
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    $DscScriptPath = $pwd
   
	Node localhost
	{		               
        
		LocalConfigurationManager 
		{ 
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		} 
				
		WindowsFeature ADPowershell
		{
			Name = "RSAT-AD-PowerShell"
			Ensure = "Present"
		} 
		
         WindowsFeature InstallWebServer
        {
            Name = "Web-Server"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]ADPowershell"
        }
        
        WindowsFeature InstallWebAsp
        {
            Name = "Web-Asp-Net45"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]InstallWebServer"
        }

        WindowsFeature InstallWebConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]InstallWebAsp"
        }

		xDnsServerAddress DnsServerAddress
		{
			Address        = $DomainControllerIp
			InterfaceAlias = $InterfaceAlias
			AddressFamily  = 'IPv4'
		}

		 xWaitForADDomain WaitForDomain 
		{ 
			DomainName = $DomainName 
			DomainUserCredential= $DomainCredentials
			RetryCount = $RetryCount 
			RetryIntervalSec = $RetryIntervalSec
			DependsOn = "[xDnsServerAddress]DnsServerAddress" 
		}

		xComputer DomainJoin
		{
			Name = $env:COMPUTERNAME
			DomainName = $DomainName
			Credential = $DomainCredentials
			DependsOn = "[xWaitForADDomain]WaitForDomain" 
		}
					 		
		xIEEsc DisableIEEsc 
        { 
            IsEnabled = $false 
            UserRole = "Users" 
        } 	    
        
        CloudConnector InstallCloudConnector
        {
            CustomerId = $CustomerId
            APIClientID = $ClientId
            APIClientSecret = $ClientSecret
            ResourceLocation = $customerResourceLocationsId
            ConnectorDowloadPath = $DscScriptPath				
            DependsOn = "[xComputer]DomainJoin"
        }
		
		
		Script CustomScript
		{
			SetScript = {
				$downloadPath = (Join-Path -Path $DscScriptPath -ChildPath "CustomScript.ps1")
				try{
					Invoke-WebRequest -Uri $CustomCloudConnectorScriptUri -OutFile $downloadPath
				}
				catch [System.Net.WebException] {
					Throw "Unable to download CustomScript $_"
				}
				if (Test-Path $downloadPath) {
					Write-Host "CustomScript downloaded succesfully from $downloadsUri to $downloadPath"
					Start-Process $downloadPath $CustomCloudConnectorScriptArgs -Wait
				}
			
			}
			TestScript = { 
				[string]::IsNullOrWhitespace($CustomCloudConnectorScriptUri)
			}
			GetScript = { 
				@{ }
			}     
		DependsOn = "[CloudConnector]InstallCloudConnector"			
		}

		
	}	
} 
